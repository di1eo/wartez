<?php
if(isset($_POST['name'], $_POST['email'], $_POST['phone'], $_POST['address'], $_POST['size'], $_POST['quantity'])) {
    // Replace with your Telegram Bot token and chat ID
    $apiToken = "5928613510:AAH9Er-8Yr8hySQi9EbRJiAXssqxONQ48PM";
    $chatId = "@wartezw";

    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $size = $_POST['size'];
    $quantity = $_POST['quantity'];

    // Create message text
    $message = "New order!\n\nName: $name\nEmail: $email\nPhone: $phone\nAddress: $address\nSize: $size\nQuantity: $quantity";

    // Send message to Telegram using API
    $url = "https://api.telegram.org/bot$apiToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);
    $response = file_get_contents($url);

    // Check if message was sent successfully
    if($response) {
        echo "Thank you for your order!";
    } else {
        echo "There was an error sending your order. Please try again later.";
    }
}
?>
